import React, { Component } from 'react';

class Nav extends Component {
	render() {
		return (
			<div>
				homepg?
			</div>
		)
	}
}

export default Nav;