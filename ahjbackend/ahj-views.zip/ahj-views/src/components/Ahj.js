import React, { Component } from 'react';

class Ahj extends Component {

	render() {
		return (
			<div>
				{this.props.ahj.Name}
			</div>
		)
	}
}


export default Ahj;