import React, { Component } from 'react';

class Ahjs extends Component {

	renderList() {
		return this.props.ahjs.map((ahj, index) => {
			return(
				<li key={index}>
					<div className="test"
					onClick={(e)=>{this.props.clickAhjHandler(e, ahj.id)}}
					>
					{ahj.Name}
					</div>
				</li>
			)
		})
	}
	render() {
		return (
			<ul>
			{this.renderList()}
			</ul>
		)
	}
}

export default Ahjs;