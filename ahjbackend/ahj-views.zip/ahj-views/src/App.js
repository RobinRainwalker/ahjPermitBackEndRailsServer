import React, { Component } from 'react';
import Footer from './components/Footer';
import Ahjs from './components/Ahjs';
import Ahj from './components/Ahj';
import Nav from './components/Nav';
import axios from 'axios';
import './App.css';

class App extends Component {

  constructor() {
    super();
    this.state = {
      ahjs: [],
      ahj: [],
      // search: '',
      mode: '',
      current: false,
      url: 'http://localhost:3000/ahjs',
      results: []
    }
  }

  componentDidMount() {
    this.getAhjs();
  }

  getAhjs() {
    axios.get(this.state.url)
      .then(data => {
        this.setState({
          mode: "ahjs",
          ahjs: data.data.ahjs
        });
      })
  }

  getAhj() {
    axios.get(`${this.state.url}/${this.state.shownAhjId}`)
      .then(data => {
        this.setState({
          ahj: data.data
        })
      })
      console.log("testing")
  }

  clickAhjHandler(event, ahjId) {
    event.preventDefault();
    this.setState({
      shownAhjId: ahjId,
      mode: "ahj"
    })
    console.log(this.state.ahj)
    this.getAhj()
  }

  renderView() {
    console.log(this.state.mode)
    if (this.state.mode === "ahjs") {
      // console.log('ahjs')
      return(<Ahjs 
        ahjs={this.state.ahjs}
        clickAhjHandler={this.clickAhjHandler.bind(this)}
        getAhj={this.getAhj.bind(this)}
      />)
    } 
    else if (this.state.mode === "ahj") {
      return(<Ahj 
        // currentId={this.state.shownAhjId}
        ahj={this.state.ahj}
        />)
    }
  }
  

  render() {
    return (
      <div className="App">
        <Nav />
        {this.renderView()}
        <Footer />
      </div>
    );
  }
}

export default App;
